# 水处理加药计算系统

## 安装依赖
npm install

## 运行开发服务器
npm run dev

## 构建生产版本
npm run build
