// src/modules/dosing/p1/index.js
export { calcP1Coag } from './coag'
export { calcP1Aid } from './aid'