// src/modules/dosing/p2/index.js
export { calcP2Coag } from './coag'
export { calcP2Aid } from './aid'